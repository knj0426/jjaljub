package com.knj.jjaljub

import android.content.Context
import android.net.Uri
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView

class MainRvAdaptor(val context: Context, val jjalList: ArrayList<Jjal>) :
        RecyclerView.Adapter<MainRvAdaptor.Holder>() {
    inner class Holder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val jjalImage = itemView.findViewById<ImageView>(R.id.jjalImage)

        fun bind (jjal:Jjal, context: Context) {
            val uri = Uri.parse(jjal.path)
            jjalImage.setImageURI(uri)
        }
    }

    override fun getItemCount(): Int {
        return jjalList.size
    }

    override fun onBindViewHolder(p0: Holder, p1: Int) {
        p0.bind(jjalList[p1], context)
    }

    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): Holder {
        val view = LayoutInflater.from(context).inflate(R.layout.main_rv_item, p0, false)
        return Holder(view)
    }
}