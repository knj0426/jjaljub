package com.knj.jjaljub

import android.net.Uri
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.GridLayoutManager
import android.support.v7.widget.LinearLayoutManager
import io.realm.Realm
import kotlinx.android.synthetic.main.activity_create_jjal.*
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        Realm.init(this)
        val defaultRealm = Realm.getDefaultInstance()
        defaultRealm.executeTransaction { realm ->
            val jjalList = ArrayList<Jjal>()
            for (jjal : Jjal in realm.where(Jjal::class.java).findAll()) {
                jjalList.add(jjal)
            }
            val mAdaptor = MainRvAdaptor(this, jjalList)
            mRecyclerView.adapter = mAdaptor

            val lm = GridLayoutManager(this, 2)
            mRecyclerView.layoutManager = lm
            mRecyclerView.setHasFixedSize(true)
//            for (jjal in realm.where(Jjal::class.java).findAll()) {
//                Log.d("JjalJub", "${jjal.id}")
//                Log.d("JjalJub", "${jjal.path}")
//                val fileUri = Uri.parse(jjal.path)
//            }
        }
    }
}
